package Fibonacci;

public class entryPoint {
	public static void main(String[] args) {
		new Fibonacci();
	}
	

}
