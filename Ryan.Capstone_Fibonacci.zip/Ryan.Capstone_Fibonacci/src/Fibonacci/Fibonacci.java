package Fibonacci;

public class Fibonacci {

	{
		// Where integers are defined to use throughout the program
		//A and B are = to 1 so that the program has components to add together.
		int a = 1;
		int b = 1;
		//C is = t 0 because C is the base as to where the addition will be built from.
		int c = 0;
		
		//This while loop calculates the first two numbers of the sequence then displays them.
		//What this loop is doing is having the integer C adding 1 to the value until the value of C is less than or equal to 1
		while (c < 1) {
			//C++ is having 1 add on to c
			c++;
			//These system commands are displaying C after having 1 added to it 
			System.out.println(c);
			System.out.println(c);
		}

		// This while loop calculate the sequence starting from 2
		// this while loop says to calculate every number in the sequence until the value hits less than or equal to the 45th Fibonacci number
		while (c <= 1134903171) {
			//this is saying everytime the loop goes a + b will be added to c
			c = a + b;
			System.out.println(c + "");
			//This is how the loop will end and not continue for ever
			a = b;
			b = c;
		}

	}
}
